<img src="https://g.top4top.io/p_2253ocnon0.jpg" alt="Link-X">
An Automated Tool to Hack Victim's Camera, Microphone, Location, Clipboard. Has 2 Extra Features.

## Version 1.1 Update
<li> Fixed Some Major Bugs

<li> Data Saving Directory Changed To Storage Folder

# Features
<li> Hack Camera

<li> Hack Microphone

<li> Hack Clipboard

<li> Hack Location 

<li> Get So Many Details about Victim's Device. As much as Possible...

<li> Prank Victim Using PasteJacking

<li> Supports Custom HTML page to Show to Victim.

<li> Supports URL Masking

### Supported Port Forwardings
<li> Localhost

<li> CloudFlared

<li> Ngrok


### Installation Commands
``` she'll script
apt update -y
apt upgrade -y
pkg install python git -y
git clone https://github.com/Toxic-Noob/Link-X
cd Link-X
bash setup.sh
python link-x.py
```

# Note
[*] USE IT, AT YOUR OWN RISK

[*] ToxicNoob is not Responsible for Any Misuse


## Contact
[*] Contact with Me via Email

ContactWithToxicNoob@gmail.com

### Tool ScreenShots :
<img src="https://l.top4top.io/p_2256b4bpl0.jpg" alt="Link-X 1">
<img src="https://a.top4top.io/p_2256ahw7y1.jpg" alt="Link-X 2">
<img src="https://i.top4top.io/p_2256a3eog0.jpg" alt="Link-X 3">
<img src="https://j.top4top.io/p_2256rqag21.jpg" alt="Link-X 4">



### Visitors :


![Visitor Count](https://profile-counter.glitch.me/Toxic-Noob/count.svg)
